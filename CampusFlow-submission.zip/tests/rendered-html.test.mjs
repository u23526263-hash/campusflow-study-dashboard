import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("https://campusflow.example/", { headers: { accept: "text/html", "x-forwarded-host": "campusflow.example", "x-forwarded-proto": "https" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the CampusFlow dashboard and social metadata", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>CampusFlow — Student Dashboard<\/title>/i);
  assert.match(html, /Good morning, David\./);
  assert.match(html, /Dashboard prototype/);
  assert.match(html, /Focus goal/);
  assert.match(html, /aria-label="Main navigation"/);
  assert.match(html, /property="og:image" content="https:\/\/campusflow\.example\/og\.png"/);
  assert.doesNotMatch(html, /codex-preview|SkeletonPreview|Your site is taking shape/i);
});

test("includes interactive task controls and required project assets", async () => {
  const [page, layout, css, packageJson] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/layout.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
    readFile(new URL("../package.json", import.meta.url), "utf8"),
    access(new URL("../public/og.png", import.meta.url)),
  ]);

  assert.match(page, /^"use client";/);
  assert.match(page, /function addTask/);
  assert.match(page, /function toggleAssignment/);
  assert.match(page, /aria-modal="true"/);
  assert.match(page, /aria-pressed=\{item\.completed\}/);
  assert.match(layout, /generateMetadata/);
  assert.match(css, /@media \(max-width: 700px\)/);
  assert.doesNotMatch(packageJson, /react-loading-skeleton/);
});
