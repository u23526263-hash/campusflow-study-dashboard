"use client";

import { type CSSProperties, type FormEvent, useMemo, useState } from "react";

type Tone = "coral" | "green" | "gold" | "blue";
type Filter = "all" | "open" | "done";
type Assignment = {
  id: number;
  day: string;
  month: string;
  title: string;
  course: string;
  tag: string;
  tone: Tone;
  completed: boolean;
};

const navItems = [
  ["⌂", "Overview"],
  ["✓", "Tasks"],
  ["□", "Calendar"],
  ["◫", "Courses"],
  ["↗", "Progress"],
];

const seedAssignments: Assignment[] = [
  { id: 1, day: "20", month: "AUG", title: "Research brief", course: "Communication Studies", tag: "High priority", tone: "coral", completed: false },
  { id: 2, day: "21", month: "AUG", title: "Dashboard prototype", course: "Web Development", tag: "In progress", tone: "blue", completed: false },
  { id: 3, day: "25", month: "AUG", title: "Data analysis quiz", course: "Business Analytics", tag: "Not started", tone: "gold", completed: false },
  { id: 4, day: "18", month: "AUG", title: "Reading reflection", course: "Academic Literacy", tag: "Completed", tone: "green", completed: true },
];

export default function Home() {
  const [assignments, setAssignments] = useState(seedAssignments);
  const [filter, setFilter] = useState<Filter>("open");
  const [activeNav, setActiveNav] = useState("Overview");
  const [modalOpen, setModalOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notice, setNotice] = useState("");

  const openCount = assignments.filter((item) => !item.completed).length;
  const visibleAssignments = useMemo(() => {
    if (filter === "open") return assignments.filter((item) => !item.completed);
    if (filter === "done") return assignments.filter((item) => item.completed);
    return assignments;
  }, [assignments, filter]);

  const metrics = [
    { label: "Tasks due", value: String(openCount), note: openCount > 1 ? "2 need attention" : "You're nearly clear", tone: "coral" },
    { label: "Course progress", value: "78%", note: "+8% this month", tone: "green" },
    { label: "Focus time", value: "14.5h", note: "of 20h weekly goal", tone: "gold" },
    { label: "Study streak", value: "3 days", note: "Personal best: 8", tone: "blue" },
  ];

  function selectNav(label: string) {
    setActiveNav(label);
    const targets: Record<string, string> = { Tasks: "assignments", Courses: "next-class", Progress: "focus-goal" };
    const target = targets[label];
    if (target) document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "center" });
    if (label === "Calendar") setNotice("Calendar view is planned for the next version.");
  }

  function toggleAssignment(id: number) {
    setAssignments((current) => current.map((item) => item.id === id
      ? { ...item, completed: !item.completed, tag: item.completed ? "In progress" : "Completed", tone: item.completed ? "blue" : "green" }
      : item));
  }

  function addTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const dueDate = new Date(`${String(form.get("dueDate"))}T12:00:00`);
    const priority = String(form.get("priority"));
    const priorityMap: Record<string, Tone> = { High: "coral", Medium: "gold", Normal: "blue" };
    const title = String(form.get("title"));

    setAssignments((current) => [...current, {
      id: Date.now(),
      day: String(dueDate.getDate()).padStart(2, "0"),
      month: dueDate.toLocaleString("en-ZA", { month: "short" }).toUpperCase(),
      title,
      course: String(form.get("course")),
      tag: priority === "High" ? "High priority" : "Not started",
      tone: priorityMap[priority] ?? "blue",
      completed: false,
    }]);
    setFilter("open");
    setModalOpen(false);
    setNotice(`“${title}” was added to your task list.`);
    event.currentTarget.reset();
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">C</span><span>Campus<span>Flow</span></span></div>
        <nav className="nav" aria-label="Main navigation">
          <p className="nav-label">Workspace</p>
          {navItems.map(([icon, label]) => (
            <button className={`nav-item ${activeNav === label ? "active" : ""}`} type="button" onClick={() => selectNav(label)} key={label}>
              <span aria-hidden="true">{icon}</span>{label}
              {label === "Tasks" && <b>{openCount}</b>}
            </button>
          ))}
        </nav>
        <div className="semester-card">
          <div className="semester-head"><span>Semester 2</span><strong>68%</strong></div>
          <div className="semester-track"><span /></div>
          <p>Week 5 of 13</p>
        </div>
        <div className="profile">
          <span className="avatar">DM</span>
          <div><strong>David M.</strong><small>Student</small></div>
          <button aria-label="Open profile menu" onClick={() => setNotice("Profile settings selected.")}>•••</button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><p className="eyebrow">WEDNESDAY · 19 AUGUST</p><h1>Good morning, David.</h1><p>Here&apos;s what needs your attention today.</p></div>
          <div className="top-actions">
            <div className="notification-wrap">
              <button className="icon-button" aria-label="Notifications" aria-expanded={notificationsOpen} onClick={() => setNotificationsOpen((value) => !value)}>♢<span /></button>
              {notificationsOpen && <div className="notification-popover" role="status"><strong>2 reminders</strong><p>Web Development starts at 10:30.</p><p>Research brief is due tomorrow.</p></div>}
            </div>
            <button className="primary-button" onClick={() => setModalOpen(true)}><span>＋</span> Add task</button>
          </div>
        </header>

        <section className="focus-banner" id="next-class">
          <div>
            <span className="banner-kicker">NEXT UP · 10:30</span>
            <h2>Web Development</h2>
            <p>Lab 4 · Building responsive interfaces</p>
          </div>
          <div className="banner-action">
            <span className="time-chip">Starts in 42 min</span>
            <button onClick={() => setNotice("Class details opened — Lab 4, Room B12.")}>View class <span>→</span></button>
          </div>
          <div className="banner-orb orb-one" /><div className="banner-orb orb-two" />
        </section>

        <section className="metric-grid" aria-label="Study summary">
          {metrics.map((metric) => (
            <article className={`metric-card ${metric.tone}`} key={metric.label}>
              <div className="metric-top"><span>{metric.label}</span><i /></div>
              <strong>{metric.value}</strong>
              <p>{metric.note}</p>
            </article>
          ))}
        </section>

        <section className="dashboard-grid">
          <article className="panel assignments-panel" id="assignments">
            <div className="panel-heading">
              <div><span className="section-kicker">UPCOMING</span><h2>Assignments</h2></div>
              <label className="filter-select"><span className="sr-only">Filter assignments</span><select value={filter} onChange={(event) => setFilter(event.target.value as Filter)}><option value="open">Open tasks</option><option value="done">Completed</option><option value="all">All tasks</option></select></label>
            </div>
            <div className="assignment-list">
              {visibleAssignments.length ? visibleAssignments.map((item) => (
                <div className={`assignment ${item.completed ? "completed" : ""}`} key={item.id}>
                  <button className="task-check" aria-label={`${item.completed ? "Reopen" : "Complete"} ${item.title}`} aria-pressed={item.completed} onClick={() => toggleAssignment(item.id)}>{item.completed ? "✓" : ""}</button>
                  <div className="date-block"><strong>{item.day}</strong><span>{item.month}</span></div>
                  <div className="assignment-copy"><h3>{item.title}</h3><p>{item.course}</p></div>
                  <span className={`status ${item.tone}`}>{item.tag}</span>
                  <button className="assignment-open" aria-label={`Open ${item.title}`} onClick={() => setNotice(`${item.title} selected.`)}>→</button>
                </div>
              )) : <div className="empty-state"><span>✓</span><strong>Nothing here</strong><p>Change the filter or add a new task.</p></div>}
            </div>
          </article>

          <article className="panel goal-panel" id="focus-goal">
            <div className="panel-heading"><div><span className="section-kicker">THIS WEEK</span><h2>Focus goal</h2></div><button aria-label="Focus goal options" onClick={() => setNotice("Weekly focus target: 20 hours.")}>•••</button></div>
            <div className="goal-ring" style={{"--progress": "72.5%"} as CSSProperties}>
              <div><strong>14.5</strong><span>of 20 hours</span></div>
            </div>
            <p className="goal-message"><span>↗</span> You&apos;re <strong>2.5 hours ahead</strong> of last week.</p>
            <div className="week-bars" aria-label="Daily focus time">
              {[45, 66, 86, 54, 28, 8, 8].map((height, index) => (
                <div key={index}><span style={{height: `${height}%`}} className={index === 2 ? "today" : ""} /><small>{["M","T","W","T","F","S","S"][index]}</small></div>
              ))}
            </div>
          </article>
        </section>
      </main>

      {modalOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.currentTarget === event.target && setModalOpen(false)}>
          <section className="task-modal" role="dialog" aria-modal="true" aria-labelledby="task-modal-title">
            <div className="modal-heading"><div><span className="section-kicker">NEW ITEM</span><h2 id="task-modal-title">Add a task</h2></div><button type="button" aria-label="Close dialog" onClick={() => setModalOpen(false)}>×</button></div>
            <form onSubmit={addTask}>
              <label>Task name<input name="title" placeholder="e.g. Finish project notes" autoFocus required /></label>
              <label>Course<input name="course" placeholder="e.g. Web Development" required /></label>
              <div className="form-row">
                <label>Due date<input name="dueDate" type="date" defaultValue="2026-08-26" required /></label>
                <label>Priority<select name="priority" defaultValue="Normal"><option>Normal</option><option>Medium</option><option>High</option></select></label>
              </div>
              <div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setModalOpen(false)}>Cancel</button><button type="submit" className="primary-button">Add task</button></div>
            </form>
          </section>
        </div>
      )}

      {notice && <div className="toast" role="status"><span>✓</span><p>{notice}</p><button aria-label="Dismiss message" onClick={() => setNotice("")}>×</button></div>}
    </div>
  );
}
